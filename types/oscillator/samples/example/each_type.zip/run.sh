#!/bin/bash -l

numranks=4
dt=0.25
endt=5
grid=64x64x64
osc=oscillator_list.osc
xml=analysis_config.xml
exe=oscillator

mpirun -n $numranks $exe -s $grid --dt $dt --t-end $endt --shortlog -f $xml $osc
